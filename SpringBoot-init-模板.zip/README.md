~~~txt
com
└── hzy
    └── project
        ├── annotation        # 自定义注解
        ├── aop               # 切面和切面相关的类
        ├── common            # 公共工具类和方法
        ├── config            # 配置类
        ├── constant          # 常量类
        ├── controller        # 控制器类（接收请求、处理逻辑）
        ├── exception         # 异常类和异常处理器
        ├── mapper            # 数据访问层（数据库访问接口）
        ├── model             # 数据模型类（实体类、DTO等）
        └── service           # 业务逻辑层（服务层）
~~~

