package com.hzy.project.exception;

import com.hzy.project.common.AppHttpCodeEnum;

/**
 * 自定义异常类
 */
public class BusinessException extends RuntimeException {

    private final int code;

    public BusinessException(int code, String message) {
        super(message);
        this.code = code;
    }

    public BusinessException(AppHttpCodeEnum appHttpCodeEnum) {
        super(appHttpCodeEnum.getMessage());
        this.code = appHttpCodeEnum.getCode();
    }

    public BusinessException(AppHttpCodeEnum appHttpCodeEnum, String message) {
        super(message);
        this.code = appHttpCodeEnum.getCode();
    }

    public int getCode() {
        return code;
    }
}
