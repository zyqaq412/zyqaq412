package com.hzy.muban;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MubanApplication {

    public static void main(String[] args) {
        SpringApplication.run(MubanApplication.class, args);
    }

}
