package com.hzy.project.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hzy.project.model.entity.User;


/**
 * 用户 Mapper
 *
 */
public interface UserMapper extends BaseMapper<User> {

}




